import HaddopMethods.FirstWordMap.FirstWordCounters;
import HaddopMethods.SecondWordDecade.SecondWordDecadeCounters;
import HaddopMethods.ThirdRelativeNMPISort.ThirdRelativeNMPISortCounters;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.jobcontrol.JobControl;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;
import java.util.LinkedList;

public class CollocationExtraction {
    //input nmpi mpi inputpath

    public static void main(String[] args) {
        try {
            Job job1 = FirstWordCounters.getJob();
            FileInputFormat.addInputPath(job1, new Path(args[2]));
            //todo: add 2 gram to input path
            FileOutputFormat.setOutputPath(job1, new Path("/firstMapOutput"));

            Job job2 = SecondWordDecadeCounters.getJob();
            FileInputFormat.addInputPath(job2, new Path("/firstMapOutput"));
            FileOutputFormat.setOutputPath(job2, new Path("/secondMapOutput"));

            Job job3 = ThirdRelativeNMPISortCounters.getJob(args[0], args[1]);
            FileInputFormat.addInputPath(job3, new Path("/secondMapOutput"));
            FileOutputFormat.setOutputPath(job3, new Path("/MapReduceOUTPUT"));


            //todo: remove the middle folders.

            job1.waitForCompletion(true);
            job2.waitForCompletion(true);
            job3.waitForCompletion(true);
            /*
            String command = "rm -r firstMapOutput secondMapOutput";
            Process process = Runtime.getRuntime().exec(command);
             */
        } catch (InterruptedException|IOException|ClassNotFoundException e) {
            e.printStackTrace();
            System.out.println("Error caught");
        }
        /*
        ControlledJob controlledJob1 = new ControlledJob(job1,new LinkedList<ControlledJob>());
        ControlledJob controlledJob2 = new ControlledJob(job2,new LinkedList<ControlledJob>());
        ControlledJob controlledJob3 = new ControlledJob(job3,new LinkedList<ControlledJob>());
        //controlledJob2.addDependingJob(controlledJob1);
        //controlledJob3.addDependingJob(controlledJob2);
        JobControl jc = new JobControl("JC");
        jc.addJob(controlledJob1);
        //jc.addJob(controlledJob2);
        //jc.addJob(controlledJob3);
        jc.run();
         */
    }
}
