public class ExtractCollections {

    public static void main(String[] args) {
        //Job חרטא
    }
}
